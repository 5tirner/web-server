print("<h1>Hello from python</h1>")
print("<h1>Hello from python</h1>")