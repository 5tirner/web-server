#!/usr/bin/ruby

puts "<html><body>This is a test</body></html>"
