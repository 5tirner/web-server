#!/bin/bash
echo -e "Content-type: application/pdf\n"
curl https://www.junkybooks.com/administrator/thebooks/64b13842d687b-boundaries-when-to-say-yes-how-to-say-no-to-take-control-of-your-life.pdf