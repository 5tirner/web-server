#!/bin/bash
echo -en "Content-Type: img/png\r\n\r\n"
curl https://cdn.tutsplus.com/cdn-cgi/image/width=537/net/uploads/legacy/511_http/http_diagram.png
