#!/bin/bash
curl https://github.com/