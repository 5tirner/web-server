#!/usr/bin/env perl
use strict;
use warnings;
print <<'END';
Status: 200 OK
Content-type: text/html

<!doctype html>
<html> HTML Goes Here </html>
END
